module ChaCuN {
    requires javafx.controls;
    requires java.net.http;

    exports ch.epfl.chacun;
    exports ch.epfl.chacun.gui;
    exports ch.epfl.chacun.tile;
}